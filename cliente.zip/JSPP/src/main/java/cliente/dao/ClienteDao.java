package cliente.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import cliente.model.Cliente;

public class ClienteDao {

	public int cadastrarCliente(Cliente cliente) throws ClassNotFoundException{
		String iNSERT_USERS_SQL = "INSERT INTO cliente(nome,sobrenome,login,senha,endereco,contato)"
				+"VALUES(?,?,?,?,?,?);";
		
		int resultado =0;
		try(Connection connection = DriverManager.getConnection("");
			PreparedStatement preparedStatement=connection.prepareStatement(INSERT_USERS_SQL)){
			
		}
	}
}
 